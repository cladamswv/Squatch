# Squatch Crossing 2.0.1 boot hotfix

- Reorders PlayCanvas startup to match the documented standalone flow.
- Removes unused engine keyboard/mouse/touch device creation on Android.
- Renders the HTML menu before procedural 3D scene generation.
- Reduces initial procedural world size for faster mobile startup.
- Adds a visible boot/error overlay so a runtime failure never appears as a silent black screen.
- Makes the app shell sizing more defensive for Android WebView.
